<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

define('DATE', 1);
define('OPEN', 2);	
define('MOST_POPULAR', 3);
define('TOP_RATED', 4);	

class Search extends CI_Controller {
	
	public function index(){
		$data = NULL;
		
		// Models
		$this->load->model('search_model', 'model');
		
		// Get search string
		if (@$_GET['s']){
			$reviews_data = $this->model->search();
			
			if ($reviews_data){
				
				$data['reviews_data'] = $reviews_data;
				$data['search_string'] = $_GET['s'];
				$data['submenu'] = TRUE;		
			
			} else {
				$data['reviews_data'] = NULL;	
			}
		}
		
		$this->_load_page($data);
	}
	
	// Find review data for search resultbox
	public function search_resultbox($search_str){
		
		// Handle review search bar
		if (trim($search_str)){
			
			$this->load->model('search_model', 'model');
		
			$reviews_data = $this->model->search_resultbox($search_str);
			
			if (!empty($reviews_data)){
				echo json_encode($reviews_data);
				exit;
			}
		}
	}
	
	public function category(){
		$this->load->model('search_model', 'model');
		
		$reviews_data = $this->model->get_reviews_categories();	
		
		$data = NULL;
		
		if ($reviews_data){
			$filter = NULL;
			
			if ($this->uri->segment(4)) $filter = $this->uri->segment(4);
			
			$data['reviews_data'] = $reviews_data;
			$data['submenu'] = TRUE;
			$data['filter'] = $filter;
		}	
				
		$this->_load_page($data);	
	}
	
	public function open(){		
		$this->load->model('search_model', 'model');
		
		$data = NULL;
		
		$reviews_data = $this->model->get_reviews_by(OPEN);
		
		if ($reviews_data){
			$data['reviews_data'] = $reviews_data;
		}	
				
		$this->_load_page($data);	
	}
	
	public function most_popular(){
		$this->load->model('search_model', 'model');
		
		$data = NULL;	
		
		$reviews_data = $this->model->get_reviews_by(MOST_POPULAR);
		
		if ($reviews_data){
			$data['reviews_data'] = $reviews_data;
		}
				
		$this->_load_page($data);		
	}
	
	public function recent(){
		$this->load->model('search_model', 'model');
		
		$data = NULL;		
		
		$reviews_data = $this->model->get_reviews_by(DATE);
		
		if ($reviews_data){
			$data['reviews_data'] = $reviews_data;
		}
				
		$this->_load_page($data);
	}
	
	public function top_rated(){
		$this->load->model('search_model', 'model');	
		
		$data = NULL;	
		
		$reviews_data = $this->model->get_reviews_by(TOP_RATED);
		
		if ($reviews_data){
			$data['reviews_data'] = $reviews_data;
		}
				
		$this->_load_page($data);		
	}
	
	private function _load_page($args){
		$header['title'] = 'Search Reviews';
		$header['sources'] = array(
			'css - normalize',
			'css - hydro',
			'css - layout',
			'css - search',
			'css - /foundation_icons/foundation_icons',
			'js - jquery',
			'js - general',
			'js - search'
		);
		
		
		//Setup review and pagination data
		$this->load->model('search_model', 'model');
		$this->load->model('global_data', 'global');
		$data['categories'] = $this->model->get_categories();		
		$data['current_page'] = $this->model->page_current;
		
		if ($args){
			$data['reviews'] = $args['reviews_data'];
			$data['data'] = $args;
		}
		
		//Views
		$this->load->view('header', $header);
		$this->load->view('search_titlebar_view');
		$this->load->view('search_view', $data);
		
		// Only if enough results are shown display footer
		//if ($data['reviews'] > 6)	
			//$this->load->view('footer_view.php');
	}
}