<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Register extends CI_Controller {
	
	public function index(){
		$this->load->helper('url');
		
		//Define BASE path constant
		define('BASE', base_url());
		
		if ($this->input->post())
			$this->_insert_user();
				
		$this->_load_page();	
	}	
	
	private function _insert_user(){
		$this->load->model('register_model', 'model');		
		
		$errors = $this->model->insert_user();
		
		if (empty($errors))
			echo 'user inserted';
		else 
			echo $errors;
	}
	
	public function activate(){
		//helpers
		$this->load->helper('url');
		
		$activation_code = @$this->uri->segment(3);		
		
		if (strlen($activation_code) == 32) {
			echo 'activation code SET';
		} else {
			echo 'Email sent to email address. Click link to activate account and remember to check junk/spam folder.';	
		}
	}
	
	private function _load_page(){
		$header['title'] = 'Register';
		$header['sources'] = array(
			'css - normalize',
			'css - hydro',
			'css - layout',
			'js - jquery',
			'js - general'
		);
		
		//views
		$this->load->view('header', $header);		
		$this->load->view('titlebar_view.php');
		$this->load->view('register_view.php');
	}
}