<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class New_review extends CI_Controller {
	
	public function index(){
		$this->load->model('global_data', 'global');
		
		$validate_review = TRUE;
		
		// Prevent page from being accessed without logging in
		$this->global->restrict_page();
						
		// Helpers
		$this->load->helper('url');
		
		// Display page content
		$this->_load_page();
		
		if ($this->input->post())
			$this->validate_review();
	}
	
	private function validate_review(){
		
		$this->load->model('new_review_model', 'model');
		
		// If invalid review data
		if (!$this->model->valid_review()){
			
			// Remove <p> tag from validation errors
			 $this->form_validation->set_error_delimiters('', '');
			 
			 // If no errors then honeypot is filled so redirect
			 if (validation_errors())
			 	echo validation_errors();
			 else {
				 redirect(base_url().'new-review');
				 
				 exit;
			 }
		
		} else {
		
			// If form filled and contains valid information		
			$error = $this->model->store_review();
			
			if (empty($error)){
				$this->load->model('global_data', 'global');			
				
				$title = $this->global->url_encode($this->model->review['title']);
				$id = $this->model->review['id'];
				
				$url = base_url()."reviews/$id/$title";
				
				redirect(base_url().'new-review');
				exit;
			
			} else {
				echo $error;
				exit;
			}
		}		
	}
	
	private function _load_page(){
		$header['title'] = 'New Review';
		$header['sources'] = array(
			'css - normalize',
			'css - hydro',
			'css - layout',
			'css - jquery.rating',
			'css - new_review',
			'js - jquery',
			'js - jquery.rating',
			'js - general',
			'js - new_review'
		);
		
		/*
			Get categories 
			using the search model class
		*/
		$this->load->model('search_model');
		$this->load->model('global_data', 'global');				
		
		$data['categories'] = $this->search_model->get_categories();
		$data['post_token'] = $this->session->userdata('post_token');
		
		//views
		$this->load->view('header', $header);
		$this->load->view('titlebar_view', $data);
		$this->load->view('new_review_view');
		//$this->load->view('footer.view.php');
	}
}