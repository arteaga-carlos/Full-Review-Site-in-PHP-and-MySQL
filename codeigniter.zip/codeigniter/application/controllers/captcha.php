<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Captcha extends CI_Controller {
	
	public function index(){ 
		
		$this->load->helper('captcha');
		$this->load->helper('file');
		$this->load->helper('url');
		
		$cap_settings = array(
			'word' 			=> '',
			'img_path' 		=> 'C:/wamp/www/codeigniter/application/images/captcha/',
			'img_url' 		=> base_url().'application/images/captcha/',
			'font_path' 	=> 'C:/wamp/www/codeigniter/application/fonts/SACRAFIC.ttf',
			'img_width' 	=> '250',
			'img_height' 	=> '80',
			'expiration' 	=> 1800
		);
		
		// Delete previously created captchas
		delete_files('C:/wamp/www/codeigniter/application/images/captcha/');
		
		$cap = create_captcha($cap_settings); 					echo '<pre>'; print_r($cap); echo '</pre>';
		
		//echo $cap['image'];
	}
}