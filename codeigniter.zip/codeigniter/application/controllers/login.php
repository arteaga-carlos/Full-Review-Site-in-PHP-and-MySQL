<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Login extends CI_Controller {
	
	public function index(){				
		//helpers
		$this->load->helper('url');
		
		//base url
		define('BASE', base_url());
		
		//check if user is logged in to display form or redirect
		$this->_login();	
	}
	
	private function _login(){
		$this->load->model('login_model');		
		
		if ($this->login_model->form_filled()){
			
			//If user correctly logged in redirect to requested URL
			if ($this->login_model->user_exists()){
				
				if ($this->session->userdata('request_url')){
					redirect('http://'.$this->session->userdata('request_url'));
					exit;
				} else {
					redirect(base_url().'account');
				}
				
				exit;
			} else {
				echo 'Invalid username or password.';	
			}
			
		//If form not filled show form
		} else {
			$this->_display_login();
		}
		
		//If user already logged in redirect to account page
		if ($this->login_model->user_loggedin()){
			redirect(BASE);
			exit;
		}
	}
	
	private function _display_login(){
		//load file resources
		$header['title'] = 'Login';
		$header['sources'] = array(
			'css - normalize',
			'css - hydro',
			'css - layout',
			'css - login.css',
			'js - jquery',
			'js - general'
		);
		
		//views
		$this->load->view('header.php', $header);		
		$this->load->view('titlebar_view.php');
		$this->load->view('login_view');
		//$this->load->view('footer.view.php');
	}
	
	//Update raiting for threads
	public function raiting_update(){	
		$this->load->model('login_model');
		
		if ($this->login_model->user_loggedin())
			echo 'raiting will be updated';
		else
			echo 'you are NOT logged in.';
	}
	
	public function reset_password(){
		echo 'password reset page';	
	}
	
	public function go(){
		
		if ($this->uri->segment(3)){
			echo $this->uri->segment(3) ;
		}
	}
}