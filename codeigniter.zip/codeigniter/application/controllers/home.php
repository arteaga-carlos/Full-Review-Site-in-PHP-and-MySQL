<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Home extends CI_Controller {
	
	public function index(){		
		$header['title'] = 'Home Page';
		$header['sources'] = array(
			'css - normalize',
			'css - hydro',
			'css - layout',
			'css - jquery.rating',
			'css - /foundation_icons/foundation_icons',
			'js - jquery',
			'js - jquery.rating',
			'js - general'
		);
				
		//helpers
		$this->load->helper('url');
		
		//base url
		define('BASE', base_url());
		
		//views
		$this->load->view('header', $header);
		$this->load->view('titlebar_view');	
		$this->load->view('home');
		//$this->load->view('footer_view');
	}
}