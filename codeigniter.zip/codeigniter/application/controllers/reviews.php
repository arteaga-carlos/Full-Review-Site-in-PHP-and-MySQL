<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Reviews extends CI_Controller {
	
	public function index(){		
		$this->load->helper('url');
		
		redirect(base_url().'search/open');
	}
	
	// Get reviews by id passed in through URL redirection
	public function get_review($review_id, $review_title){
		
		$this->load->model('reviews_model', 'model');		
		$review_data = $this->model->get_review($review_id);
		
		// If review data is available load page
		if ($review_data)
			$this->_load_page($review_data);
		 else 
			show_404();		
	}
	
	// Get comments through AJAX
	public function get_comments(){						
		
		$this->load->model('reviews_model', 'model');
		
		if (is_numeric($this->uri->segment(3)) && $this->_valid_position(@$_GET['position'])){
			
			// Get position from URL and convert to int to avoid errors
			$position = (int) $_GET['position'];
			
			$comments = $this->model->get_comments($this->uri->segment(3), $position);
		
			if ($comments){
				echo json_encode($comments);
				exit;
			
			} else {
				echo 0;
				exit;	
			}	
		
		} else {
			echo 0;
			exit;	
		}
	}
	
	private function _valid_position($position){
		
		if (is_numeric($position)){
			
			$t = (int) $position;
			
			if ($t > -1)
				return true;
			else
				return false;
		
		} else {
			return false;	
		}
	}
	
	public function comment_review(){
		
		// If user logged in
		if ($this->session->userdata('username')){ 
			
			if ($this->input->post()){
			
				$this->load->model('reviews_model', 'model'); 
				$errors = $this->model->comment_review();
				
				if (empty($errors)){
					echo 'Review created.';
				} else {
					echo $errors;
				}
		
			} else 
				show_404();
		} else
			echo 'You must be logged in.';				
	}
	
	public function flag_review(){
		
		if (!$this->input->post()) { show_404(); exit; }
		
		$this->load->model('reviews_model', 'model');
		
		$error = $this->model->flag_review();
		
		if (empty($error)){
			echo 1;
			exit;
		} else {
			echo $error;
			exit;	
		}
	}
	
	public function like(){
		
		if ($this->input->post()){			
			$this->load->model('reviews_model', 'model');
			
			$error = $this->model->like();
			
			if (empty($error)){
				echo 1;
				exit;
			} else {
				echo $error;
				exit;	
			}
			
		} else 
			show_404();
	}
	
	private function _load_page($review_data){		
		
		$header['title'] = $review_data['title'];
		$header['sources'] = array(
			'css - normalize',
			'css - hydro',
			'css - layout',			
			'css - reviews',
			'css - jquery.rating',
			'css - /foundation_icons/foundation_icons',
			'js - jquery',
			'js - angular',
			'js - jquery.rating',
			'js - general',
			'js - reviews'
		);
		
		//Set login variable
		$review_data['user_loggedin'] = ($this->session->userdata('username')) ? $this->session->userdata('username') : NULL;
		$review_data['options'] = TRUE;
		
		//Views
		$this->load->view('header', $header);
		$this->load->view('titlebar_view', $review_data);
		$this->load->view('reviews_view', $review_data);
		//$this->load->view('footer.view.php');
	}	
}