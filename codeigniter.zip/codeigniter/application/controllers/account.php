<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Account extends CI_Controller {
	
	public function index(){
		$this->load->model('global_data', 'global');								
		//Helpers
		$this->load->helper('url');
		
		//Base url
		define('BASE', base_url());
		
		//Prevent page from being accessed without logging in
		$this->global->restrict_page();
		
		//Load page content
		$this->_load_page();
	}
	
	private function _load_page(){
		//load file resources
		$header['title'] = 'Account';
		$header['sources'] = array(
			'css - normalize',
			'css - hydro',
			'css - layout',
			'css - account.css',
			'js - jquery',
			'js - general'
		);
		
		//views
		$this->load->view('header.php', $header);		
		$this->load->view('titlebar_view.php');
		$this->load->view('account_view.php');
		//$this->load->view('footer.view.php');	
	}
	
	public function logout(){
		$this->load->model('global_data', 'global');
		$this->global->logout();
	}
}