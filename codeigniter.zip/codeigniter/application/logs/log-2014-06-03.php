<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-06-03 21:31:48 --> Config Class Initialized
DEBUG - 2014-06-03 21:31:48 --> Hooks Class Initialized
DEBUG - 2014-06-03 21:31:48 --> Utf8 Class Initialized
DEBUG - 2014-06-03 21:31:48 --> UTF-8 Support Enabled
DEBUG - 2014-06-03 21:31:48 --> URI Class Initialized
DEBUG - 2014-06-03 21:31:48 --> Router Class Initialized
DEBUG - 2014-06-03 21:31:48 --> Output Class Initialized
DEBUG - 2014-06-03 21:31:48 --> Security Class Initialized
DEBUG - 2014-06-03 21:31:48 --> Input Class Initialized
DEBUG - 2014-06-03 21:31:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-03 21:31:48 --> Language Class Initialized
DEBUG - 2014-06-03 21:31:48 --> Loader Class Initialized
DEBUG - 2014-06-03 21:31:48 --> Session Class Initialized
DEBUG - 2014-06-03 21:31:48 --> Helper loaded: string_helper
DEBUG - 2014-06-03 21:31:48 --> Encrypt Class Initialized
DEBUG - 2014-06-03 21:31:48 --> Database Driver Class Initialized
DEBUG - 2014-06-03 21:31:48 --> Session routines successfully run
DEBUG - 2014-06-03 21:31:48 --> Controller Class Initialized
DEBUG - 2014-06-03 21:31:48 --> Helper loaded: captcha_helper
DEBUG - 2014-06-03 21:31:48 --> Helper loaded: url_helper
DEBUG - 2014-06-03 21:31:48 --> Final output sent to browser
DEBUG - 2014-06-03 21:31:48 --> Total execution time: 0.2163
DEBUG - 2014-06-03 21:31:49 --> Config Class Initialized
DEBUG - 2014-06-03 21:31:49 --> Hooks Class Initialized
DEBUG - 2014-06-03 21:31:49 --> Utf8 Class Initialized
DEBUG - 2014-06-03 21:31:49 --> UTF-8 Support Enabled
DEBUG - 2014-06-03 21:31:49 --> URI Class Initialized
DEBUG - 2014-06-03 21:31:49 --> Router Class Initialized
DEBUG - 2014-06-03 21:31:49 --> Output Class Initialized
DEBUG - 2014-06-03 21:31:49 --> Security Class Initialized
DEBUG - 2014-06-03 21:31:49 --> Input Class Initialized
DEBUG - 2014-06-03 21:31:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-03 21:31:49 --> Language Class Initialized
DEBUG - 2014-06-03 21:31:49 --> Loader Class Initialized
DEBUG - 2014-06-03 21:31:49 --> Session Class Initialized
DEBUG - 2014-06-03 21:31:49 --> Helper loaded: string_helper
DEBUG - 2014-06-03 21:31:49 --> Encrypt Class Initialized
DEBUG - 2014-06-03 21:31:49 --> Database Driver Class Initialized
DEBUG - 2014-06-03 21:31:49 --> Session routines successfully run
DEBUG - 2014-06-03 21:31:49 --> Controller Class Initialized
DEBUG - 2014-06-03 21:31:49 --> Helper loaded: captcha_helper
DEBUG - 2014-06-03 21:31:49 --> Helper loaded: url_helper
DEBUG - 2014-06-03 21:31:49 --> Final output sent to browser
DEBUG - 2014-06-03 21:31:49 --> Total execution time: 0.0892
DEBUG - 2014-06-03 21:31:49 --> Config Class Initialized
DEBUG - 2014-06-03 21:31:49 --> Hooks Class Initialized
DEBUG - 2014-06-03 21:31:49 --> Utf8 Class Initialized
DEBUG - 2014-06-03 21:31:49 --> UTF-8 Support Enabled
DEBUG - 2014-06-03 21:31:49 --> URI Class Initialized
DEBUG - 2014-06-03 21:31:49 --> Router Class Initialized
DEBUG - 2014-06-03 21:31:49 --> Output Class Initialized
DEBUG - 2014-06-03 21:31:49 --> Security Class Initialized
DEBUG - 2014-06-03 21:31:49 --> Input Class Initialized
DEBUG - 2014-06-03 21:31:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-03 21:31:49 --> Language Class Initialized
DEBUG - 2014-06-03 21:31:49 --> Loader Class Initialized
DEBUG - 2014-06-03 21:31:49 --> Session Class Initialized
DEBUG - 2014-06-03 21:31:49 --> Helper loaded: string_helper
DEBUG - 2014-06-03 21:31:49 --> Encrypt Class Initialized
DEBUG - 2014-06-03 21:31:49 --> Database Driver Class Initialized
DEBUG - 2014-06-03 21:31:49 --> Session routines successfully run
DEBUG - 2014-06-03 21:31:49 --> Controller Class Initialized
DEBUG - 2014-06-03 21:31:49 --> Helper loaded: captcha_helper
DEBUG - 2014-06-03 21:31:49 --> Helper loaded: url_helper
DEBUG - 2014-06-03 21:31:49 --> Final output sent to browser
DEBUG - 2014-06-03 21:31:49 --> Total execution time: 0.0775
DEBUG - 2014-06-03 21:31:49 --> Config Class Initialized
DEBUG - 2014-06-03 21:31:49 --> Hooks Class Initialized
DEBUG - 2014-06-03 21:31:49 --> Utf8 Class Initialized
DEBUG - 2014-06-03 21:31:49 --> UTF-8 Support Enabled
DEBUG - 2014-06-03 21:31:49 --> URI Class Initialized
DEBUG - 2014-06-03 21:31:49 --> Router Class Initialized
DEBUG - 2014-06-03 21:31:49 --> Output Class Initialized
DEBUG - 2014-06-03 21:31:49 --> Security Class Initialized
DEBUG - 2014-06-03 21:31:49 --> Input Class Initialized
DEBUG - 2014-06-03 21:31:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-03 21:31:49 --> Language Class Initialized
DEBUG - 2014-06-03 21:31:49 --> Loader Class Initialized
DEBUG - 2014-06-03 21:31:49 --> Session Class Initialized
DEBUG - 2014-06-03 21:31:49 --> Helper loaded: string_helper
DEBUG - 2014-06-03 21:31:49 --> Encrypt Class Initialized
DEBUG - 2014-06-03 21:31:49 --> Database Driver Class Initialized
DEBUG - 2014-06-03 21:31:49 --> Session routines successfully run
DEBUG - 2014-06-03 21:31:49 --> Controller Class Initialized
DEBUG - 2014-06-03 21:31:49 --> Helper loaded: captcha_helper
DEBUG - 2014-06-03 21:31:49 --> Helper loaded: url_helper
DEBUG - 2014-06-03 21:31:49 --> Final output sent to browser
DEBUG - 2014-06-03 21:31:49 --> Total execution time: 0.0775
DEBUG - 2014-06-03 21:33:51 --> Config Class Initialized
DEBUG - 2014-06-03 21:33:51 --> Hooks Class Initialized
DEBUG - 2014-06-03 21:33:51 --> Utf8 Class Initialized
DEBUG - 2014-06-03 21:33:51 --> UTF-8 Support Enabled
DEBUG - 2014-06-03 21:33:51 --> URI Class Initialized
DEBUG - 2014-06-03 21:33:51 --> Router Class Initialized
DEBUG - 2014-06-03 21:33:51 --> Output Class Initialized
DEBUG - 2014-06-03 21:33:51 --> Security Class Initialized
DEBUG - 2014-06-03 21:33:51 --> Input Class Initialized
DEBUG - 2014-06-03 21:33:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-03 21:33:51 --> Language Class Initialized
DEBUG - 2014-06-03 21:33:51 --> Loader Class Initialized
DEBUG - 2014-06-03 21:33:51 --> Session Class Initialized
DEBUG - 2014-06-03 21:33:51 --> Helper loaded: string_helper
DEBUG - 2014-06-03 21:33:51 --> Encrypt Class Initialized
DEBUG - 2014-06-03 21:33:51 --> Database Driver Class Initialized
DEBUG - 2014-06-03 21:33:51 --> Session routines successfully run
DEBUG - 2014-06-03 21:33:51 --> Controller Class Initialized
ERROR - 2014-06-03 21:33:51 --> Severity: Notice  --> Use of undefined constant DEBUG - assumed 'DEBUG' C:\wamp\www\codeigniter\application\controllers\captcha.php 7
ERROR - 2014-06-03 21:33:51 --> Severity: Notice  --> Use of undefined constant MESSAGE - assumed 'MESSAGE' C:\wamp\www\codeigniter\application\controllers\captcha.php 7
DEBUG - 2014-06-03 21:33:51 --> MESSAGE
DEBUG - 2014-06-03 21:33:51 --> Helper loaded: captcha_helper
DEBUG - 2014-06-03 21:33:51 --> Helper loaded: url_helper
DEBUG - 2014-06-03 21:33:51 --> Final output sent to browser
DEBUG - 2014-06-03 21:33:51 --> Total execution time: 0.1940
