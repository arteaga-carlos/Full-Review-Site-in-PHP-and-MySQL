// Reviews JS

var reviews_module = angular.module('ReviewsApp', []);
	
// Controllers	
reviews_module.controller('CommentsController', function($scope, $http, Service){
	
	// Config
	description_text_limit = 300;
	
	$scope.comments_data = null;
	$scope.comment_count = null;
	$scope.show_more = show_more;
	
	function set_comments(){					
	
		var comments = Service.getComments();      										alert(comments); return;
		
		if ( comments ){
			
			// Initialize comments_data if it doesn not have any data.
			if ( $scope.comments_data == null ) $scope.comments_data = comments.comments_data;
			
			// When [show more] button is pressed there will be data so merge new data with old
			else $scope.comments_data = $scope.comments_data.concat(comments.comments_data);	
		}
	}
	
	// Handler for [show more] button
	function show_more(){
		
		// If [Show More] button is disabled do not trigger
		if ($('#show-more').hasClass('disabled'))
			return false;	
		
		// Update next comments result position
		var $ul = $('.review-comments').find('ul'),
		 	$show_more = $('#show-more'),
		
		 	ul_current_position = parseInt($ul.attr('data-position')),
		 	comment_limit = parseInt($show_more.data('comment-limit')),
		 	update_position = ul_current_position + comment_limit;
		
		$ul.attr('data-position', update_position);
		
		set_comments();
		
		return false;
	}
	
	
	
	// Display comments on page load
	set_comments();
		
});

reviews_module.service('Service', function ($http){
	
	// Retrieve Comments from Server
	this.getComments = function(){
		
		var 	
			$comments = $('.review-comments').find('ul'),
			$comments_wrapper = $('.review-comments'),
			$show_more_btn = $('#show-more'),
			review_id = $('#review-topic').data('review-id'),
			position = $comments.attr('data-position'),
			message = $show_more_btn.text();
		
		// Get comment data
		$http.get(base_url() + 'reviews/get-comments/' + review_id + '/?position=' + position)		
			.success(function(data){
				
				if ( ! data ) return null;
				
				return {
								
					// Truncate description text
					comments_data : truncate_description(data.comments),
					
					// Set metadata
					comment_count : data.comment_count,
					comments_per_page : data.comments_per_page,
					logged_in : data.logged_in,
					more_results : data.more_results
				};																		
		});
	}
	
	
	truncate_description = function(comments){
		
		for (var i = 0; i < comments.length; i++)
			comments[i].description = truncate_text(comments[i].description, description_text_limit)
		
		return comments;
	}
	
	
	// Append 'show more' link if description exceeds limit
	truncate_text = function(text, maxLength){
	
		// Hide the rest of the text based on description size limit
		if(text.length >= maxLength){
			var a = text;
			var $read_more_button = '<a class="read-more" href="#">read more</a><span class="hidden">';
			
			a = a.substring(0, maxLength + 1);							
			a = a.substring(0, a.lastIndexOf(' '));
			
			b = text.substring(a.length);
			b = b + '</span>';
			  
			a = a + $read_more_button;
			
			text = a + b;
		}
		
		return text;
	}
});

$(document).ready(function(){
	
	window.starRating = null;
	window.user_loggedin = 0;
	
	//Submit review button non obstructive
	//$('#insert-submit').click(submit_comments);
	
	//Get star rating
	$('#rating').on('click', '.star', function(){		
		starRating = $(this).index();
	});
	
	//$review_comments = $('.review-comments');
	// Like comments
	//$review_comments.on('click', 'a.like', like);
	//Read more (description)
	//$review_comments.on('click', '.read-more', read_more);
	
	//Flag controls
	/*$('#close-dialog').click(close_dialog);
	$('#dialog-no').click(close_dialog);
	$('#dialog-yes').click(flag_review);
	$('#flag').click(open_dialog);*/
	
	tooltip_likes_create();
});





// Submit flag
/*function flag_review(){
	
	var id = $('#review-topic').data('review-id');
	
	$.ajax({
		url: base_url() + 'reviews/flag-review',
		type: 'post',
		data: {review_id: id},
		success: function(result){
			
			if (result == '1'){
				
				$('.confirmation').text('Thank you for you feedback.');
			
			} else {
				$('.confirmation').text(result);
			}
			
			// Hide dialog box
			setTimeout(function(){
				$('.overlay').fadeOut(200);
			}, 1000);
		}
	});
	
	return false;
}*/





// Submit comments on reviews
/*function submit_comments(){
	
	// Set rating
	starRating = (starRating === null) ? 3 : starRating;
		
	// Get value of all available form children
	var 
		title = $('#insert-title').val(),
		description = $('#insert-description').val().trim(),
		tag = $('#insert-tag').val();
		id = $('#insert-form').data('review-id');
		
	// Send post data as Ajax to create review comment
	$.ajax({
		url: base_url() + 'reviews/comment-review',
		type: 'post',
		data: {title: title, rating: starRating, description: description, tag: tag, review_id: id},
		success: function(result){
			alert(result);	
		},
		error: function(error){
			alert(error.status);
		}
	});
	
	return false;	
}

// Like button functionality
function like(){
	
	// Disable function if user not logged in
	if ( window.user_loggedin == 0 ) return false;
	
	$this = $(this);
	
	$.ajax({
		type: 'post',
		url: base_url() + 'reviews/like',
		data: {comment_id: $(this).data('comment-id'), action: $this.text()},
		success: function(result){
			
			if (result == '1'){
				
				// If comment liked, change text
				if ($this.text() == 'like'){
					$this.text('unlike');
				
				} else {
					$this.text('like');
				}			
			}
		}
	});
	
	return false;
}*/





// Display comment data
/*function display_comments(result){
	
	// -- Config --
	var description_limit = 300;
	
	// Remove [show-more] button
	$('a#show-more').remove();
			
	var result_comments = JSON.parse(result);	
	
	var $ul = $('.review-comments').find('ul');
	
	// Set-up JSON data
	var 
		comments_per_page = result_comments['comments_per_page'],
		comment_count = result_comments['comment_count'],
		more_results = result_comments['more_results'],
		comments = result_comments['comments'],
		user_likes,
		description,
		lis = '';
			
	// Set global data for user logged in
	window.user_loggedin = result_comments['logged_in'];
	
	// Bind tooltips for like comments
	if ( result_comments['logged_in'] == 0 ) tooltip_show();
	
	// Display Comment Count
	$('#comments-heading').html('<b>Comments (' + comment_count + ')</b>');
	
	
	// Display comments
	for (var i = 0; i < comments.length; i++){
			
		// Get which comments the user likes
		user_likes = (typeof(comments[i].user_likes) != 'string') ? 'like' : 'unlike';
		
		
		// Shorten description text length
		description = truncate_str(comments[i].description, description_limit);
		
		// Insert comments
		lis += '\
			<li class="comment-data">\
				<span class="comment-title">' + comments[i].title + '</span>\
				*' + comments[i].comment_rating + '\
				\
				<p class="comment-meta"><span class="user">by ' + comments[i].user + '</span> - ' + comments[i].date + '</p>\
				\
				<p class="comment-likes blue">(likes: ' + comments[i].likes + ') - \
					<span><a class="like" data-comment-id="' + comments[i].comment_id + '" href="#">' + user_likes + '</a></span>\
				</p>\
				\
				<p class="description text-regular">' + description +'</p>\
			</li>';
	}
	
	$ul.append(lis);
	
	// Show more button
	if (more_results == 1)
		$('.review-comments').append('<a id="show-more" class="button" data-comment-limit="' + comments_per_page + '" href="#">Show more</a>');
	
}*/



// Create show more button
/*function show_more(){
	
	// If [Show More] button is disabled do not trigger
	if ($('#show-more').hasClass('disabled'))
		return false;	
	
	// Update next comments result position
	var $ul = $('.review-comments').find('ul');
	
	var ul_current_position = parseInt($ul.attr('data-position')); 
	var comment_limit = parseInt($(this).data('comment-limit'));
	var update_position = ul_current_position + comment_limit;
	
	$ul.attr('data-position', update_position);
	
	get_comments();
	
	return false;
}*/







// Show tooltip on a specific element after an action
function tooltip_likes_create(){
	
	// Show tooltip on hover
	$('.review-comments').on({
		
		mouseenter: function(){
			
			// Check if $element already contains a tooltip then display
			if ($(this).find('span.tooltip').length){
				
				$tooltip = $(this).find('span.tooltip');
				
				// If tooltip has been setup do not run setup again
				if ($(this).hasClass('_setup')) {
					$tooltip.css('display', 'block'); 
					
					return false;
				}		
				
				tooltip_setup($tooltip, $(this));
				$tooltip.css('display', 'block');
				
				// Mark tooltip as being setup
				$(this).addClass('_setup');
				
				return false;
			}
		},
		
		mouseleave: function(){
			
			// Hide if tooltip exists
			if ($(this).find('span.tooltip').length)
				$(this).find('span.tooltip').css('display', 'none');
		}
	
	}, 'a.like');
}





// Setup read more button if description text is truncated
/*function read_more(){
	
	$(this).parent().find('.hidden').removeClass('hidden');
	
	$(this).remove();
		
	return false;	
}*/





function addBreakes(text){
	text.replace('/(?:\r\n|\r|\n)/g',  '<br />');
	
	return text;
}




