// New Review Raiting

$(document).ready(function(){
	var category = null;
	
	//Submit review button handler
	$('#submitreview').click(function(){
		
		//Submit review only if category set
		if (category != null){
			var $formnewreview = $('#formnewreview');
			
			// Insert category into new input element before submit
			var $category = $('<input type="text" name="fieldcategory" id="fieldcategory" value="' + category + '" />');
			
			$formnewreview.append($category);
			
			$formnewreview.submit();
				
		} else {
			alert('category must be set');
			
			return false;
		}
	});
	
	$categories = $('#categories');
	
	$categories.on('click', 'li', function(){
		category = $(this).text();
		
		$('#cat-title').text(category).append('<span class="arrow-down"></span>');
	});
    
	//Dropdown categories functionality
	$categories.click(function(){
		$dropdown = $(this).find('ul');
		$display = $dropdown.css('display');
		
		if ($display == 'none')		
			$dropdown.fadeIn(300);
		else
			$dropdown.fadeOut(300);
	});
});