// Search Page Javascript

$(document).ready(function(){
	
	$categories = $('#categories');
	
	$categories.on('click', 'li', function(){
		var url = base_url() + 'search/category/' + $(this).text().toLowerCase() + '/';		
		window.location = url;
	});
    
	//Dropdown categories functionality
	$categories.click(function(){
		$dropdown = $(this).find('ul');
		$display = $dropdown.css('display');
		
		if ($display == 'none')		
			$dropdown.fadeIn(300);
		else
			$dropdown.fadeOut(300);
	});
	
	// Get result set from typing in search box
	$('#text-search').keyup(key_search);
	
	// Submit search form
	$('#search-submit').click(search_submit);
});


//Display Ajax preloader
function ajax_loader(on){
	$reviews = $('#reviews');
	
	if (on === true){
		$reviews.find('ul').css('visibility', 'hidden');
		$reviews.addClass('ajax-preloader');	
	} else if (on === false){
		$reviews.find('ul').css('visibility', 'visible');
		$reviews.removeClass('ajax-preloader');
	}
}

function key_search(){
	var string = $.trim($(this).val());
	
	if (string != '' && string != null){
		
		$.ajax({
			url: base_url() + 'search/search-resultbox/' + url_encode(string),
			type: 'get',
			success: function(result){
				
				var $result_box = $('.result-box');
				
				try {
					var review_results = JSON.parse(result);	
				
				} catch(e){
					$result_box.text('No results found.');
				}
				
				if(typeof(review_results) == 'undefined'){
					$result_box.text('No results found.');
					$result_box.css('display', 'block');
					
					return;
				}
				
				$result_box.text('');
				$result_box.find('ul').remove();
				$result_box.append("<ul></ul>");
				
				var uri,
					title,
					id,
					lis = "";
				
				for (var i = 0; i < review_results.length; i++){
					
					title = truncate(review_results[i].title, 50, '...');
					uri = "http://localhost/codeigniter/reviews/" + review_results[i].id + "/" + url_encode(review_results[i].title);
					
					lis += "<li><a href='" + uri + "'>" + title + "</a></li>";				
				}
				
				// Insert LIs in the UL
				$result_box.find('ul').append(lis);
				
				$result_box.css('display', 'block');
			}
		});
	
	} else {
		$('.result-box').css('display', 'none');	
	}
}

function search_submit(){
	
	var search_str = $.trim($('#text-search').val());
	
	if (search_str != '')
		$('#form-search').submit();
	
	
	return false;
}

function valid_string(string){
	
	if (string.match("/[^a-zA-Z0-9\s]/")){
		
	}
}

function url_encode(string){
	
	if (string){
		string = 
			string.toLowerCase()
			.replace(/[^a-z0-9 -]/g, '')
			.replace(/\s+/g, '-')
			.replace(/-+/g, '-');
		
		return string;			
	}	
}