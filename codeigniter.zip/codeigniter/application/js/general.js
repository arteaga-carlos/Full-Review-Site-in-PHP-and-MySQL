// Main Setup

var GlobalModule = angular.module('GlobalModule', []);

$(document).ready(function(){
	
	//hide JavaScript div check if js enabled
	$('#js-check').css('display', 'none');
	
	//Enable tooltips
	tooltips_create();
});

// Set main URL
function base_url(){
	
	return 'http://localhost/codeigniter/';
}

function open_dialog(){
	$('.overlay').fadeIn(200);	
}

function close_dialog(){
	$('.overlay').fadeOut(200);	
}

// Create tooltips for every element that contains it
function tooltips_create(){
	
	$('.tooltip').each(function(){
		
		var $tooltip = $(this);
		var $parent = $tooltip.parent();
		
		tooltip_setup($tooltip, $parent);
		
		$parent.bind({
		
			mouseenter: function(){		
				$tooltip.css('display', 'block');				
			},
			
			mouseleave: function(){				
				$tooltip.css('display', 'none');				
			}
		});
	});	
}

// Prepare tooltip to be positioned correctly
function tooltip_setup($tooltip, $parent){
	
	var padding = parseInt($tooltip.css('paddingLeft'));
	var width = parseInt($tooltip.width());
	var margin = '-' + ( (width / 2) + padding ) + 'px';
	
	$parent.css('position', 'relative');
	$tooltip.css('marginLeft', margin);
}

// Append 'show more' link if description exceeds limit
GlobalModule.service('GlobalService', function (){
	
	this.truncate_str = function (text, maxLength, marker){
	
		// Hide the rest of the text based on description size limit
		if(text.length >= maxLength){		
			
			text = text.substring(0, maxLength + 1);						
			text = text.substring(0, text.lastIndexOf(' '));	
			
			text = text + marker;
		}
		
		return text;
	}
});