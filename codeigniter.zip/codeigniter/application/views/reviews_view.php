<!--Dialog box for review flagging-->
<div class="overlay">
	
    <div class="dialog">
    	
        <div class="row divisor gray">
        	
            <div class="row divisor-bottom">
            
            	<div class="six columns">
            		<span class="dialog-heading">Flag Review</span>
                </div>
                
                <div class="six columns">
                	<a id="close-dialog" href="#"><i class="fi-x size-16"></i></a>
                </div>
            </div>
        </div>
            
        <div class="row">
           	<div class="twelve columns">
               	<p>You are about to flag this comment for review. Read the <a class="blue" href="#">guidelines</a> to learn more.</p>
                <p class="text-center confirmation">Are you sure you wish to flag this comment for removal?</p>
            </div>
        </div>
        
        <div class="row">
           	<div class="six columns text-center">
            	<a id="dialog-yes" class="button" href="#">Yes</a>
            </div>
            
            <div class="six columns text-center">
               	<a id="dialog-no" class="button" href="#">No</a>
            </div>
        </div>
    </div>
</div>


																		

<div class="container" ng-app="ReviewsApp">
		
  <div class="row">
  
      <div class="twelve columns">
      
          <div class="review-main">
          
              <div class="row">
              
                  <div class="twelve columns">
                      <?php
                          
                          // Display Main Review
                          echo "
                              <h2 id='review-topic' class='text-heading' data-review-id='$review_id'>$title - <span>$category</span></h2>
                              <p class='text-gray text-regular'>by <span class='user'>$username</span> - $date</p>								
                          ";                              
                      ?>
                   </div>
              </div>
              
              <div class="row">     
                  
                  <div class="three columns">                      
                      <div class="main-rating">
                      	<div>
                          <?php						  
                               // Display review score
                              if ($review_rating == 0)
                                  echo '?';
                              else
                                  echo $review_rating;
                          ?>
                          </div>
                      </div>                              
                 </div>
              </div>
              
              <div class="row">
              
                  <div class="twelve columns">
                      <p class="description"><?php echo $description; ?></p>
                 </div>
              </div>
         </div>
     </div>
  </div>
  
  <div class="row">																	
  
      <div class="twelve columns">
  		  
          <!------------------ Comments ------------------>
          <div class="review-comments" ng-controller="CommentsController">
          
              <div class="row">
              
                  <div class="twelve columns">
                      <span id="comments-heading" ng-if="comment_count"><b>Comments ({{ comment_count }})</b></span>
                      <span id="comments-heading" ng-if="!comment_count"><b>Comments (0)</b></span>
                  </div>                       
              </div>
              
              <div class="row divisor-top">
              
                  <div class="eight columns">                     
                        
                      <ul data-position="0">     						                 		 
                          
                          <div ng-if="comments_data">																												
                          
                              <!--Diplay comments-->
                              <li class="comment-data" ng-repeat="comment in comments_data">
                                  
                                  <span class="comment-title"> {{ comment.title }} </span>
                                  
                                  <p class="comment-meta"><span class="user">by {{ comment.user }} </span> - {{ comment.date }} </p>
                                  
                                  <p class="comment-likes text-blue text-regular">
                                  	  likes: {{ comment.likes }}  - 
                                      
                                      <span ng-if="logged_in == 1">
                                          <a class="like" data-comment-id=" {{ comment.comment_id }} " ng-if="comment.user_likes == 1" href="#">unlike</a>
                                          <a class="like" data-comment-id=" {{ comment.comment_id }} " ng-if="comment.user_likes == 0" href="#">like</a>
                                      </span>
                                      
                                      <span ng-if="logged_in == 0">
                                      	  <a class="like" data-comment-id=" {{ comment.comment_id }} " ng-if="comment.user_likes == 0" href="#">
                                          	like
                                            <span class="tooltip">Please Log In</span>
                                          </a>
                                      </span>
                                  </p>
                                  
                                  <p  class="description text-regular">{{ comment.description }}</p>
                                      
                                  <p class="comment-rating text-regular">Rating: <span>{{ comment.comment_rating }}</span></p>
                              </li>
                              
                              <!--[Show More] button-->
                              <a id="show-more" class="button" data-comment-limit=" {{ comments_per_page }} " ng-if="more_results == 1" ng-click="show_more()" href="">Show more</a>
                          </div>                          
                      </ul>                   
                  </div>                 
                  
              </div>
          </div>
      </div>
  </div>
  
  
  
  
  
  <div class="row divisor-top">
  
      <div class="twelve columns">
      
          <div class="insert-comment">
              
              <?php
              
                  // If user is logged in display comment section
                  if ($user_loggedin){
              ?>
              
                  <!--Insert Comment Section-->
                  
                  <div class="row">
                      
                     <div class="row">
                          
                          <div class="twelve columns">
                              <span class="insert-heading">Comment Review</span>
                          </div>
                     </div>
                      
                      <div class="seven columns">                                                       	
                          
                          <form id="insert-form" method="post" action="<?php echo base_url()."reviews/comment-review/$review_id"; ?>" 
                              data-review-id="<?php echo $review_id; ?>">
                              
                              <table>
                                  <tr>
                                      <td>
                                          <input class="input" id="insert-title" type="text" name="insert-title" placeholder="Title" maxlength="50" />
                                      </td>
                                  </tr>  
                                  <tr><td><textarea class="input text-regular" rows="5" cols="15" id="insert-description" name="insert-description"></textarea></td></tr>  
                                  <tr>
                                      <td>
                                          <span class="rate-comment"><b>Rate: </b></span>
                                          <div id="rating">                     
                                           <input name="star2" type="radio" class="star" id="star" title="Terrible" />
                                           <input name="star2" type="radio" class="star" id="star" title="Bad" />
                                           <input name="star2" type="radio" class="star" id="star" title="Ok" checked="checked"/>
                                           <input name="star2" type="radio" class="star" id="star" title="Good" />
                                           <input name="star2" type="radio" class="star" id="star" title="Excellent" />                        
                                         </div>
                                          
                                      </td>
                                  </tr>
                                  <tr><td><input class="button" type="submit" name="insert-submit" value="Comment" id="insert-submit" /></td></tr>
                              </table>
                          </form>
                          
                      </div>
                      
                      <div class="three columns offset-by-1">
                      
                          <div id="rules">
                              <i class="fi-alert size-24"></i>
                              <span>Rules</span>
                              
                              <ul>
                                  <li>Title must not be longer than 50 characters long.</li>
                                  <li>No obcene language.</li>
                                  <li>No spam.</li>
                              </ul>
                          </div>
                      </div>
                  </div>
                  
              <?php
                  
                  } else {
                      
                      // User NOT logged in
                      echo '<span class="login-warning">You must be logged in to post comments.</span>';
                  }
              ?>
         </div>
     </div>
  </div>
</div>