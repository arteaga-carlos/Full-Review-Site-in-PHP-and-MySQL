<div class="container">  
  
  <div class="content shadow">
  	
    <div class="row">
    
        <div class="six columns">
            Review and find reviews on anything. Comment and be heard.
        </div>
        
        <div class="six columns">
        	
            <div class="comments-gallery">
                <ul class="comments">
                    <li>
                        <span class="title">Perfect Gam and yes some title <b>[thebombhgtyuhfdseftd]</b></span>
                        <p>charly - 04-01-2014</p>
                        <p>Description of the comments go here. and we can have some more information inserted into this little space here. Another thing is that lorem ipsum can have a lot more.</p></li>
                    <li>
                        <span class="title">Perfect Game <b>[thebomb]</b></span>
                        <p>charly - 04-01-2014</p>
                        <p>Description of the comments go here.</p></li>
                    <li>
                        <span class="title">Perfect Game <b>[thebomb]</b></span>
                        <p>charly - 04-01-2014</p>
                        <p>Description of the comments go here.</p></li>
                </ul>
            </div>
        </div>
    </div>
  </div>
  
  <div class="content shadow">
    
    <div class="row divisor">
    
        <div class="three columns">
            <span class="reviews-title">Popular Reviews</span>
        </div>
    </div>
    
    <div class="row">
      
      <div class="nine columns">          
          <ul class="reviews">
            <li> <a href="#">The Shawshank Redemption</a>
              <p>by: <a href="#">Scott Stein</a> - Jan 11, 2014</p>
            </li>
            <li> <a href="#">Microsoft Surface Tablet</a>
              <p>by: <a href="#">Lynn La</a> - Jan 11, 2014</p>
            </li>
            <li> <a href="#">Java Programming for Dummies</a>
              <p>by: <a href="#">Ry Crist</a> - Jan 11, 2014</p>
            </li>
            <li> <a href="#">Miley Cyrus</a>
              <p>by: <a href="#">Matthew Moskovciak</a> - Jan 11, 2014</p>
            </li>
            <li> <a href="#">Neiman Marcus</a>
              <p>by: <a href="#">Xiomara Blanco</a> - Jan 11, 2014</p>
            </li>        
          </ul>
      </div>
  
  <div class="three columns">
    
  </div>
</div>
</div>
</body>
</html>