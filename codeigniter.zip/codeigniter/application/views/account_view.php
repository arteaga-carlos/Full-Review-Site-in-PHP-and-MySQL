<div class="container">
	<div class="account-setting-panel row">
    	<p class="user">administrator</p>
        <img src="<?php echo BASE.'application/images/alert_icon.png'; ?>">
    	<a class="button" href="#" title="settings"></a>
    </div>
    <a href="<?php echo BASE.'account/logout'; ?>">logout</a>
    
    <ul class="stats">
    	<li>Joined: 02/11/1991</li>
        <li>Reviews: 3</li>
        <li>reputation: 3</li>
    </ul>   
   
    <div class="row">
    	 <ul class="tabs">
            <li><a href="#">Reviews</a></li>
            <li><a href="#">Likes</a></li>
    	</ul>
    
    	<div class="twelve columns">
            <div id="reviews">
                <ul>
                	<li>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus fermentum posuere est et vulputate.</li>
                    <li>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus fermentum posuere est et vulputate.</li>
                    <li>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus fermentum posuere est et vulputate.</li>
                    <li>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus fermentum posuere est et vulputate.</li>
                    <li>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus fermentum posuere est et vulputate.</li>
                    <li>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus fermentum posuere est et vulputate.</li>
                    <li>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus fermentum posuere est et vulputate.</li>
                </ul>
            </div>
        </div>
    </div>
</div>