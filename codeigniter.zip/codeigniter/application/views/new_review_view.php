<div class="container">
	
    <div class="row">
    	
        <div class="eight columns">
        	<form name="formnewreview" id="formnewreview" method="post" action="<?php echo base_url().'new-review'; ?>">
            	<fieldset>
                	<legend>New Review</legend>
                    <input type="text" name="fieldtitle" placeholder="Review Title" class="input" id="fieldtitle" />
                    <input type="text" name="fieldname" placeholder="Review Name" class="input" id="fieldname" />
                    <textarea name="fielddescription" rows="1" cols="1" class="input" id="fieldreview" ></textarea>
                                        
                    <div id="categories" class="categories default-look">       
                        <p id="cat-title">Categories<span class="arrow-down"></span></p>          
                        <ul class="category-dropdown default-look">
                            <?php
							
                                //Create categories menu
                                foreach ($categories as $category){
                                    echo "<li>$category</li>\n";
                                }
                            ?>
                        </ul>
                    </div>
                    
                    <input type="submit" id="submitreview" class="button orange" value="Review" />
                </fieldset>
            </form>           
		</div>
        
        <div class="four columns">
        	<div class="rules">
    			Lorem ipsum dolor sit amet, nominavi qualisque dissentiunt nec ut. Insolens adolescens te duo, eum id omnium discere salutandi. Delectus electram temporibus ad qui, appetere ullamcorper et pri, an usu enim populo corpora. Enim maiorum nec ex. Cu option quaeque eos, sea in adipisci persequeris. Sea id eripuit salutandi, at appetere definitionem duo. An tollit nostro doctus sed.

Vim ne latine voluptua, his ei tacimates consequat. Ex mei malis dicant dicunt, modus electram similique eos an. Sea partem vivendo aliquando cu. Est probatus accommodare delicatissimi cu.

Ius et aperiam equidem postulant. In sint ullum tincidunt cum. Option albucius id sea, ad saperet torquatos has. Usu id stet phaedrum repudiare. Et per quem volumus, usu nemore appetere.
			</div>        	
        </div>
    </div>
</div>