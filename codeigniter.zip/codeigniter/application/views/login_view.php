<div class="container">
	<div class="row">
        <div class="six columns">
            <form name="loginform" method="post" action="" id="loginform" />
                <fieldset>                	
                	<table>
                        <legend>Login</legend>
                        <h4>Sign in to reviewit or <a href="<?php echo BASE.'register'; ?>">create</a> an account.</h4>
                        <tr><td><label for="username">Username: </label></td>
                        	<td><input type="text" name="username" id="username" class="input" /></td></tr>
                        <tr><td><label for="password">Password: </label></td>
                        	<td><input type="password" name="password" id="password" class="input" />
                            	<a href="<?php echo BASE.'login/reset-password'; ?>">forgot password</a></td></tr>
                    </table>
                    <div class="login-footer">
                    	<input type="submit" class="button green" name="submitlogin" id="submitlogin" value="Log in" />
                    </div>                   
                </fieldset>
            </form>
        </div>
        <div class="five columns">
        	<h3>Let everyone know what you think.</h3>
            <p>Join others in reviewing pretty much anything.</p>
        </div>
    </div>
</div>
<div class="push"></div>