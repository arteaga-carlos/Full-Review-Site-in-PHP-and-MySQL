<?php echo "\n"; ?>
<div class="navbar-bottom default-look">
	<div class="container">
    	<ul>
            <li><p>Copyright Reviewit.com 2014. All Rights Reserved.</p></li>
            <li><a href="#">Disclaimer</a></li>
            <li><a href="#">About</a></li>
            <li><a href="#">Contact</a></li>
        </ul>
    </div>
</div>
</body>
</html>