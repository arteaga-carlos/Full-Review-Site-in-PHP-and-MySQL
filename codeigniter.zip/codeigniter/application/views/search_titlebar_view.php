<body>
  
<div class="container">

    <div class="navbar">
		
        <div class="user-login text-regular">
			<?php
            
              // -- Display User Menu
              if ($this->session->userdata('username'))
                  echo "
                      <a href='".base_url()."account'>".$this->session->userdata('username')."</a>
                  ";
              else
                  echo "
                      <a href='".base_url()."account'>login</a>
                  ";
            ?>
        </div>
        
        <div class="navmenu">
              <form action="<?php echo base_url().'search/'; ?>" method="get" name="form-search" id="form-search" class="form-search">
                <input type="text" name="s" id="text-search" class="input" autocomplete="off" autofocus />
              	<a href="#" id="search-submit"><i class="fi-magnifying-glass size-24"></i></a>
              </form>
                
              <div class="result-box shadow">
                <ul>
                </ul>
              </div>
        </div>
    </div>
</div>

<div class="sub-navbar">
	
    <div class="container">
    	
        <div class="sub-navmenu-wrapper">
            
            <ul class="sub-navmenu">
                <li><a href="<?php echo base_url().'search/top-rated/'; ?>">TOP RATED</a></li>
                <li><a href="<?php echo base_url().'search/recent/'; ?>">RECENT</a></li>
                <li><a href="<?php echo base_url().'search/most-popular/'; ?>">MOST POPULAR</a></li>
            </ul>
                
            <?php                
                // If options menu should be displayed
                if (@$options){
            ?>
                    <ul class="options">                    
                        <?php                              
                              // Flag icon
                              if ($flag)
                                  echo '<li><i class="fi-flag flagged"></i><span class="tooltip black">Review Flagged</span></li>';
                              else
                                  echo '<li><a href="#"><i class="fi-flag"></i><span class="tooltip black">Flag Review</span></a></li>';                        ?>
                        
                        <li><a href="#"><i class="fi-heart"></i><span class="tooltip black">Favorite Review</span></a></li>
                    </ul>
            
            <?php } ?>
        </div>
    </div>
</div>