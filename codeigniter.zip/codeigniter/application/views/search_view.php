<?php

	// Set whether search is done via query strings
	$search_string = @$data['search_string'];
?>



<div class="container">
  
	<div class="row divisor-bottom">

    	<div class="six columns">
        
         	<?php 
	
			// Display submenu only for search and categories
			if (@$data['submenu']){ ?>
						
                <ul class="submenu">
                
                    <?php
                    
                        $url = base_url().'search';					
                            
                        $page_current = $this->model->page_current;
                            
                        if ($search_string)
                            echo "
                                <li><a href='?s=$search_string&f=date&p=$page_current'>Date</a></li>
                                <li><a href='?s=$search_string&f=rating&p=$page_current'>Rating</a></li>
                            ";
                        else
                            echo "
                                <li><a href='?f=date&p=$page_current'>Date</a></li>
                                <li><a href='?f=rating&p=$page_current'>Rating</a></li>
                            ";                        
                    ?>					
                </ul>
			<?php } ?>        
        </div>
        
        <div class="six columns">
            <div id="categories" class="categories default-look">
              
              <p class="heading">Categories<span class="arrow-down"></span></p>
              <ul class="category-dropdown default-look">
        
                <?php
                                
                    // -- Categories
                                                                
                    foreach ($categories as $category){
                        echo "<li>$category</li>\n";
                    } ?>
                    
             </ul>
           </div>
       </div>
    </div>      
            
	<div id="reviews">
<?php

// -------- Reviews Dislay --------	

if (@$reviews) {

echo '<ul>';
					
$i = 0;
$last_index = count($reviews);

$this->load->model('search_model', 'model');
$this->load->model('global_data', 'global');

foreach ($reviews as $review){	
	
	// DO NOT read last element of array
	// as it contains pagination information	
	
	if (++$i === $last_index) break;					
	
		$id = $review['id'];
		$date = $review['date'];
		$title = $review['title'];
		$rating = $review['rating'];
		$user = $review['username'];
		$category = $review['category'];		
		$base_url = base_url();
		$length = $this->model->search_desc_length;
		$review_url = $base_url."reviews/$id/".$this->global->url_encode($title);
		$description = $this->global->truncate($review['description'], $length);						
		
		echo "
			<li><a href='$review_url'>$title</a>
			
				<span class='category blue'> - $category</span>
		";
				
				// rating
				if ($rating != 0)
					echo "
						<div class='rating-score'>
							<i class='fi-star size-36'></i>
							<p>							
								<span>$rating</span>
							</p>
						</div>
					";
				
				// review metadata
				echo "
				<p>
					by <span class='review-user'>$user</span>
					- $date
				</p>
				<p class='review-description'>
					$description
				</p>	
			</li>							
		";								
} ?>
      
      </ul>
    </div>
  </div>
</div>





<div class="container">
    
    <div class="row">
        <div class="eleven columns">
            <?php
                 // ----- Pagination Section -----		
                
                echo "<ul class='pages'>";	
                
                foreach (end($reviews) as $page){
                    
                    if ($search_string){
                        
                        if ($page == $this->model->page_current)
                            echo "<li class='active'>$page</li>";
                        else
                            echo "<li><a href='?s=$search_string&p=$page'>$page</a></li>";
                    
                    } else if ($page == $this->model->page_current)
                        echo "<li class='active'>$page</li>";
                        
                      else 
                          echo "<li><a href='?p=$page'>$page</a></li>";
                }
                
                echo '</ul>'; ?>
        </div>
        
        <div class="one column">
            <p>veritii.com</p>
        </div>
	</div>
</div>


<?php 

// No reviews set
} else {
	echo "
		<p class='search-sign'>Search</p>
		</div>
	";	
}

?>