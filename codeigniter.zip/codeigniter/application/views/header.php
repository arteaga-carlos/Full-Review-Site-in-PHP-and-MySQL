<?php if (!isset($title)){ $title = 'Unknown'; } ?>
<!DOCTYPE HTML>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<title><?php echo $title; ?></title>

<?php 
	//get array of files to load (css or js)
	foreach ($sources as $file){
		$file = explode('-', strtolower($file));
		
		//If document type is css
		$file[1] = trim($file[1]);
		
		if (strcmp(trim($file[0]), 'css') == 0){
			echo '<link href="'.base_url()."application/css/$file[1]".'.css" rel="stylesheet" type="text/css" />'."\n";
		
		//If document is javascript
		} else if (strcmp(trim($file[0]), 'js') == 0){
			echo '<script src="'.base_url()."application/js/$file[1]".'.js" type="text/javascript"></script>'."\n";
		}
	}
?>
</head>