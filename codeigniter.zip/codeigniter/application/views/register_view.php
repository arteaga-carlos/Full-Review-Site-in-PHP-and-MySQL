<div class="container">
	<div class="row">
    	<div class="six columns">
        	<form name="registerform" method="post" action="<?php echo BASE.'register'; ?>" id="registerform" />
            	<fieldset>
                	<legend>Register</legend>
                    <table>
                        <tr><td><label for="username">Username:</label></td>
                            <td><input type="text" name="username" id="username" /></td></tr>
                        <tr><td><label for="email">Email:</label></td>
                        	<td><input type="text" name="email" id="email" /></td></tr>
                        <tr><td><label for="password">Password:</label></td>
                            <td><input type="password" name="password" id="password" /></td></tr>
                        <tr><td><label for="confirm">Confirm:</label></td>
                            <td><input type="password" name="confirm" id="confirm" /></td></tr>                    
                    </table>
                    <div><input type="submit" name="submitregister" value="Register" /></div>
                </fieldset>
            </form>
        </div>
        
        <div class="four columns">
        	<h3>Speak and be heard!</h3>
            <p>Join others in letting everyone know what you think.</p>
        </div>
    </div>
</div>