<?php
	
class Global_data extends CI_Model {
	
	function __construct(){
		//helpers
		$this->load->helper('url');
	}
	
	public function logout(){
		
		if ($this->session->userdata('username')){
			$session_data['username'];
			$session_data['user_id'];
			
			$this->session->unset_userdata($session_data);			
			$this->session->sess_destroy();
			
			redirect(base_url());
			exit;
		} else {
			redirect(base_url());
			exit;
		}
	}

	//Check if user is logged in
	public function user_loggedin(){
		
		if ($this->session->userdata('username'))
			return TRUE;
	}
	
	public function restrict_page(){
		
		//If user not logged in redirect and save requested URL
		if (!$this->user_loggedin()){
			$url = parse_url(base_url(), PHP_URL_HOST).$_SERVER['REQUEST_URI'];
			
			$this->session->set_userdata('request_url', $url);
			redirect(base_url().'login');
			exit;
		}
	}
	
	public function random_string(){
		return md5(uniqid(mt_rand(), true));	
	}
	
	public function url_encode($string){
		$string = preg_replace('/[^a-zA-Z0-9 ]/', '', strtolower($string));
		
		return preg_replace('/\s+/', '-', $string);
	}
	
	public function url_decode($string){
		return preg_replace('/\-/', ' ', $string);
	}
	
	public function truncate($text, $length) {
		
		if (strlen($text) >= $length){
			$text .= " ";
			$text = substr($text, 0, $length);
			$text = substr($text, 0, strrpos($text,' '));
			$text .= "...";
		}		
		
		return $text;
	}
}