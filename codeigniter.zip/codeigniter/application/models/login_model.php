<?php

class Login_model extends CI_Model {
	
	public function user_exists(){
		$this->load->database();
		$this->load->model('global_data', 'global');
		
		$username = $this->input->post('username');
		$password = $this->input->post('password');		
		
		$query = $this->db->query("
			SELECT id
			FROM users
			WHERE username = ?
			AND password = sha2(?, 256)
			AND activation = '0'
			LIMIT 1
		",
			array($username, $password)
		);
		
		if ($query->num_rows() === 1){ 
			$result = $query->result(); 
			
			//set session data			
			$this->session->set_userdata('username', $username);
			$this->session->set_userdata('user_id', $result[0]->id);
						
			return TRUE;
		}
	}
	
	public function form_filled(){
		$this->load->library('form_validation');
			
		$this->form_validation->set_rules('username', 'Username', 'required|alpha_numeric|min_length[4]|max_length[15]|xss_clean|trim');
		$this->form_validation->set_rules('password', 'Password', 'required|alpha_numeric|min_length[8]|max_length[20]|trim');
			
		if ($this->form_validation->run() === TRUE){
			return TRUE;
		} else {
			return FALSE;
		}
	}
	
	public function user_loggedin(){
		
		if ($this->session->userdata('username')) 
			return TRUE;
		else
			return FALSE;
	}
}