<?php

/*	The search resultbox will limit the results to titles
 *	with a length smaller than the allowed limit
 *	as described below in the $resultbox_title_limit variable
 */

class Search_model extends CI_Model {
	
	public $page_current;
	
	function __construct(){	
		
		// --------------------- Configuration ---------------------
		
		// Set maximum amount of page links to be shown
		$this->next_pages_qty = 3;
		$this->previous_pages_qty = 3;
		
		// Set amount of results per page
		$this->results_per_page = 6;
		
		// Description length for reviews searched
		$this->search_desc_length = 100;
		
		// Limit amount for search bar result box
		$this->resultbox_limit = 8;
		// Title's text length in result box
		$this->resultbox_title_limit = 50;
		
		// Set whether review results require pagination data
		$this->pagination = TRUE;
		
		// Default query order filter
		$this->filter = 'date';
		
		// ---------------------------------------------------------		
		
		
		
		// Query for resultbox with limited title length
		$this->query_search_resultbox = "
			SELECT 
				id, 
				SUBSTRING(title, 1, $this->resultbox_title_limit) AS title
			FROM reviews
			WHERE title LIKE ?
			LIMIT $this->resultbox_limit
		";
		
		$this->query_date = "
			SELECT SQL_CALC_FOUND_ROWS 
				r.id, 
				r.title,
				SUBSTRING(d.description, 1, $this->search_desc_length) AS description,
				DATE_FORMAT(r.date, '%b %d, %Y') AS date,
				GET_RATING(r.id) AS rating,
				u.username, 
				c.category
			FROM reviews r
			INNER JOIN categories c
			ON r.category_id = c.id
			INNER JOIN users u
			ON r.user_id = u.id
			INNER JOIN reviews_descriptions d
			ON r.id = d.review_id
			ORDER BY r.date DESC
			LIMIT ?, $this->results_per_page
		";
		
		$this->query_open = "
			SELECT SQL_CALC_FOUND_ROWS 
				r.id, 
				r.title,
				SUBSTRING(d.description, 1, $this->search_desc_length) AS description,
				DATE_FORMAT(r.date, '%b %d, %Y') AS date,
				GET_RATING(r.id) AS rating,
				u.username, 
				c.category
			FROM reviews r
			INNER JOIN categories c
			ON r.category_id = c.id
			INNER JOIN users u
			ON r.user_id = u.id
			LEFT OUTER JOIN comments co
			ON r.id = co.review_id
			INNER JOIN reviews_descriptions d
			ON r.id = d.review_id
			WHERE co.id IS NULL
			ORDER BY r.date DESC
			LIMIT ?, $this->results_per_page
		";
		
		$this->query_most_popular = "
			SELECT SQL_CALC_FOUND_ROWS 
				r.id, 
				r.title,
				SUBSTRING(d.description, 1, $this->search_desc_length) AS description,
				DATE_FORMAT(r.date, '%b %d, %Y') AS date,
				GET_RATING(r.id) AS rating,
				u.username, 
				c.category,
				(
					SELECT COUNT(co.id)
					FROM comments co
					WHERE co.review_id = r.id
				) AS comment_count
			FROM reviews r
			INNER JOIN categories c
			ON r.category_id = c.id
			INNER JOIN users u
			ON r.user_id = u.id
			INNER JOIN reviews_descriptions d
			ON r.id = d.review_id
			ORDER BY comment_count DESC
			LIMIT ?, $this->results_per_page
		";
		
		$this->query_top_rated = "
			SELECT SQL_CALC_FOUND_ROWS 
				r.id, 
				r.title,
				SUBSTRING(d.description, 1, $this->search_desc_length) AS description,
				DATE_FORMAT(r.date, '%b %d, %Y') AS date,
				GET_RATING(r.id) AS rating,
				u.username, 
				c.category
			FROM reviews r
			INNER JOIN categories c
			ON r.category_id = c.id
			INNER JOIN users u
			ON r.user_id = u.id
			INNER JOIN reviews_descriptions d
			ON r.id = d.review_id
			ORDER BY rating DESC
			LIMIT ?, $this->results_per_page
		";
	}
	
	
	
	
	
	// Get categories menu
	public function get_categories(){
		$this->load->database();
		
		$query = $this->db->query("
			SELECT category
			FROM categories
		");
		
		if ($query->num_rows() > 0){
			$categories = array();
			
			foreach ($query->result() as $row){
				array_push($categories, $row->category);
			}
			
			return $categories;
			
		} else 
			return NULL;
	}
	
	
	
	
	// Get reviews from search string
	public function search(){
		
		$this->load->model('global_data', 'global');
		
		$search_str = @$_GET['s'];
		$page_current = @$_GET['p'];
		$f = @$_GET['f'];
		
		$filters = array( 'rating', 'date' );
		
		if ($search_str){
			$filter = 'date';
			$search_str = $this->global->url_decode($search_str);					
			
			// Validate filter input
			if (in_array($f, $filters)) $filter = $f;
			
			// Query for search bar
			$query_search = "
				SELECT SQL_CALC_FOUND_ROWS 
					r.id, 
					r.title,
					SUBSTRING(d.description, 1, $this->search_desc_length) AS description,
					DATE_FORMAT(r.date, '%b, %d %Y') AS date,
					GET_RATING(r.id) AS rating,
					u.username, 
					c.category
				FROM reviews r
				INNER JOIN categories c
				ON r.category_id = c.id
				INNER JOIN users u
				ON r.user_id = u.id
				INNER JOIN reviews_descriptions d
				ON r.id = d.review_id
				WHERE title LIKE ?
				ORDER BY $filter DESC
				LIMIT ?, $this->results_per_page
			";
			
			$position = $this->get_position($page_current);
			$args = array('%'.$search_str.'%', $position);
			
			//Get review data
			$reviews = $this->create_review($query_search, $args);
		
			if ($reviews)
				return $reviews;	
			else
				return NULL;	
		}
	}
	
	
	
	
	
	public function search_resultbox($search_str){
		
		$this->load->model('global_data', 'global');
		
		if ($search_str){
			// Disable pagination
			$this->pagination = FALSE;
			
			$search_str = $this->global->url_decode($search_str);
			
			$reviews = $this->create_review($this->query_search_resultbox, '%'.$search_str.'%');
			
			if ($reviews)
				return $reviews;	
			else
				return NULL;
		}
	}
	
	
	
	
	
	
	// Get review information by DATE, RATING etc
	public function get_reviews_by($filter){
		
		// Get correct query based on $filter variable passed in
		switch ($filter){
			case 1: 
				$query_str = $this->query_date;
				break;
			case 2: 
				$query_str = $this->query_open;
				break;
			case 3: 
				$query_str = $this->query_most_popular;
				break;
			case 4: 
				$query_str = $this->query_top_rated;
				break;
		}
		
		$page_num = (@$_GET['p']) ? $_GET['p'] : 0;
		
		$position = $this->get_position($page_num);
		
		$reviews = $this->create_review($query_str, $position);
		
		if ($reviews)
			return $reviews;	
		else
			return NULL;
	}
	
	
	
	
	
	
	public function get_reviews_categories(){
		
		if ($this->uri->segment(3)){
			
			$filter = 'date';
			$f = (@$_GET['f']) ? $_GET['f'] : 'date';	
			
			$filters = array( 'rating', 'date' );
			
			// Validate filter input
			if (in_array($f, $filters)) $filter = $f;
			
			// Initiate query variables		
			$query_category = "
				SELECT SQL_CALC_FOUND_ROWS 
					r.id, 
					r.title,
					SUBSTRING(d.description, 1, $this->search_desc_length) AS description,
					DATE_FORMAT(r.date, '%b, %d %Y') AS date,
					GET_RATING(r.id) AS rating,
					u.username, 
					c.category
				FROM reviews r
				INNER JOIN categories c
				ON r.category_id = c.id
				INNER JOIN users u
				ON r.user_id = u.id
				INNER JOIN reviews_descriptions d
				ON r.id = d.review_id
				WHERE c.category = ?
				ORDER BY $filter DESC
				LIMIT ?, $this->results_per_page
			";		
			
			$page_num = (@$_GET['p']) ? $_GET['p'] : 0;
			$position = $this->get_position($page_num);				
			
			$args = array($this->uri->segment(3), $position);
			
			$reviews = $this->create_review($query_category, $args);
			
			if ($reviews)
				return $reviews;	
			else
				return NULL;
		}
	}
	
	
	
	
	
	
	// Create review array with pagination data
	private function create_review($query_arg, $params){	
		
		$query = $this->db->query($query_arg, $params);
			
		if ($query->num_rows() > 0){					
			$review_data = $query->result_array();
			
			/*	Second query to retrieve complete total of results
				without LIMIT clause
			*/
			$query = $this->db->query("
				SELECT FOUND_ROWS() AS record_count
			");
			
			//Get total number of rows returned
			if ($query->num_rows() === 1){
				$result = $query->result();						
				
				if ($this->pagination){
					$page_amount = $this->get_page_amount($result[0]->record_count);
					$pages = $this->set_pages($page_amount);
					
					array_push($review_data, $pages);
				}				
									
				return $review_data;
			}
		}
	}
	
	
	
	
	
	// Find next values to retrieve from database using LIMIT clause
	public function get_position($page_current){
		if ($page_current)
			// Set current page if not valid then default to 0
			$page_current = ($this->valid_page_number($page_current)) ? (int) $page_current : 0;
		else
			$page_current = 0;
				
		// Decrease page number to show correct page in URL
		$page_current = ($page_current == 0) ? 0 : --$page_current; 
		
		// Set global page for availability
		$this->page_current = $page_current;
			
		// Get starting position for results in database
		$position = $this->results_per_page * $page_current;
		
		return $position;
	}
	
	
	
	
	
		
		
	// Calculate amount of pages in total based in amount of records
	public function get_page_amount($record_count){
		$t = $record_count / $this->results_per_page;
		
		if (gettype($t) == 'double'){
			$pages = (int) $t;
			$pages++;
		
		} else {
			$pages = $t;
		}
		
		return $pages;
	}
	
	//Set array of pages
	public function set_pages($page_max){
		$pages = array();
		
		//Set current page
		$this->page_current++;
		
		$previous = $this->page_current;
		$previous--;
		
		$next = $this->page_current;
		$next++;			
		
		//Get previous pages
		while (($previous > 0) && ($this->previous_pages_qty != 0)){
			array_push($pages, $previous);
			
			$previous--;
			$this->previous_pages_qty--;
		}
		
		// Reverse previous pages's order
		$pages = array_reverse($pages);
		// Insert current page in the middle of array
		array_push($pages, $this->page_current);
																
		//Get following pages
		while (($next <= $page_max) && ($this->next_pages_qty != 0)){		
			array_push($pages, $next);
			
			$next++;
			$this->next_pages_qty--;
		}								
		
		return $pages;
	}
	
	private function valid_page_number($p){
		
		if (is_numeric($p)){			
			$page = (int)$p;
			
			 if ($page > -1) return true;			
			 
			 else return false;
			
		} else
			return false;		
	}
}