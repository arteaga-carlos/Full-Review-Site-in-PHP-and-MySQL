<?php

class New_review_model extends CI_Model {
	
	public $review;
	
	function __construct(){
		$review = array();
	}
	
	public function valid_review(){
		$this->load->library('form_validation');
		
		$this->form_validation->set_rules('fieldtitle', 'Title', 'required|min_length[5]|max_length[100]|xss_clean|trim');
		$this->form_validation->set_rules('fieldcategory', 'Category', 'required|alpha|min_length[1]|trim');
		$this->form_validation->set_rules('fielddescription', 'Description', 'required|min_length[20]|max_length[2650]|xss_clean|trim');
		
		$this->load->model('reviews_model');
		
		// Check for honeypot field, if filled discard review
		if ($this->input->post('fieldname')) return FALSE;
		
		if (($this->form_validation->run() === TRUE) && ($this->reviews_model->valid_title($this->input->post('title'))))
			return TRUE;
		else
			return FALSE;
	}
	
	public function store_review(){	
		
		$error = '';
		$this->load->model('global_data', 'global');
		$this->load->database();		
		
		$title = strip_tags($this->input->post('fieldtitle'));
		$category = $this->input->post('fieldcategory');
		$user_id = strip_tags($this->session->userdata('user_id'));
		$description = strip_tags($this->input->post('fielddescription'));
		
		/*
			Transaction used to be sure
			ALL review information is inserted
			or none is.
		*/
		
		//Insert review
		$this->db->query("START TRANSACTION");	
		$this->db->query("
		
			INSERT into reviews 
			(date, user_id, category_id, title)
			SELECT CURDATE(), ?, categories.id, ?
			FROM users
			INNER JOIN categories
			WHERE categories.category = ?
			LIMIT 1
									
		", array($user_id, $title, $category));
		
		if ($this->db->affected_rows() != 1){
			$error = 'Could not create review.';
		
		} else {			
			$reviewID = $this->db->insert_id();
						
			//Insert description				
			$this->db->query("
			INSERT INTO reviews_descriptions
			(review_id, description)
			VALUES
			(?, ?)			
			", array($reviewID, $description));			
			
				
			// If description could not be inserted
			// then rollback
				
			
			if ($this->db->affected_rows() !== 1){
				$this->db->query("ROLLBACK");
				$error = 'Review description not inserted. Create review again.';
			} else {
				$this->db->query("COMMIT");
				
				// Make created review data available
				$this->review['title'] = $title;
				$this->review['id'] = $reviewID;
			}
		}
		
		return $error;
	}
	
}