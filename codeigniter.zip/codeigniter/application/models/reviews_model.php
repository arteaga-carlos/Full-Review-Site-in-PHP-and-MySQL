<?php

class Reviews_model extends CI_Model {
	
	private $comments_per_page = 5;
	
	private $query_get_comments;
	private $query_get_review;
	private $query_like;
	private $query_unlike;
	
	function __construct(){
		
		$this->query_get_review = "
			SELECT 
				   review.id AS review_id, 
				   review.title, 
				   DATE_FORMAT(review.date, '%b %d, %Y') AS date,
				   GET_RATING(review.id) AS review_rating, 
				   flag.user_id AS flag,
				   categories.category, 
				   users.username,
				   descriptions.description
			FROM reviews AS review
			INNER JOIN categories			
			ON review.category_id = categories.id
			INNER JOIN users
			ON review.user_id = users.id
			INNER JOIN reviews_descriptions AS descriptions
			ON review.id = descriptions.review_id
			LEFT OUTER JOIN reviews_flags AS flag
			ON flag.review_id = review.id
			AND flag.user_id = ?
			WHERE review.id = ?
			LIMIT 1
		";
		
		$this->query_flag_review = "
			INSERT INTO reviews_flags
			(user_id, review_id)
			VALUES
			(?, ?)
		";
		
		$this->query_like = "
			INSERT INTO user_likes
			(user_id, comment_id)
			VALUES
			(?, ?)
		";
		
		$this->query_unlike = "
			DELETE 
			FROM user_likes
			WHERE user_id = ?
			AND comment_id = ?
		";
	}
	
/*
	-------------------------------
	--		Get Main Review Data 
	-------------------------------
*/
	
	public function get_review($review_id){
		
		if (isset($review_id)){
			$this->load->database();
			$this->load->model('global_data', 'global');
			
			$user_id = ($this->session->userdata('user_id')) ? $this->session->userdata('user_id') : 0;
			
			$query = $this->db->query($this->query_get_review, array($user_id, $review_id));
			
			if ($query->num_rows() === 1){
				$review_data = $query->result_array();				
				
				return $review_data[0];
				
			} else { return false; }
		
		} else { return false; }
	}
	
	
/*
	-------------------------------
	--		Flag Reviews
	-------------------------------
*/


	public function flag_review(){
		$error = '';
		
		if (!$this->session->userdata('user_id')) return 'You must be logged in.';
		
		$this->load->library('form_validation');
		$this->form_validation->set_rules('review_id', 'review id', 'required|numeric');		
		$this->form_validation->set_error_delimiters('', '');
		
		if ($this->form_validation->run() === TRUE){
			
			$user_id = $this->session->userdata('user_id');
			$review_id = $this->input->post('review_id');
			
			
			try {
				mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
				$query = $this->db->query($this->query_flag_review, array($user_id, $review_id));
				
				if ($this->db->affected_rows() !== 1)
					$error = 'Could not flag this review.';
			
			} catch (Exception $e){
				$error = 'You have already flagged this review.';
			}
			
			
		
		} else {
			$error = 'Could not insert review.';
		}
		
		return $error;	
	}




	
/*
	----------------------------------
	--			Get Review Comments
	----------------------------------
*/
	
	public function get_comments($review_id, $position){
		
		$this->load->model('global_data', 'global');
		
		if (isset($review_id)){
			$this->load->database();
			$this->load->model('global_data', 'global');
			
			$user_id = $this->session->userdata('user_id');
			
			
			/*
			 *	Retrieve comments information
			 *	and retrieve the value 1
			 *	for every comment retrieved
			 *	that the current logged in
			 *	user likes, else return null
			 */
			
			$query = $this->db->query("
			
				SELECT
					SQL_CALC_FOUND_ROWS
					c.title,					
					c.user_id,
					c.id AS comment_id,
					c.rating AS comment_rating,
					u.username AS user,
					
					DATE_FORMAT(c.date, '%b %d, %Y') AS date,					 
					d.description,
					
					(
						SELECT COUNT(comment_id)
						FROM user_likes
						WHERE comment_id = c.id
					)  AS likes,
					
					COALESCE(
						(
							SELECT 1
							FROM comments, user_likes
							WHERE user_likes.comment_id = c.id
							AND user_likes.user_id = ?
							LIMIT 1
						),
					0) AS user_likes
				
				FROM comments c
				INNER JOIN users u
				ON c.user_id = u.id
				INNER JOIN comments_descriptions d
				ON c.id = d.comment_id
				WHERE review_id = ?			
				ORDER BY likes DESC
				LIMIT $position, $this->comments_per_page
				
			", array($user_id, $review_id));
			
			if ($query->num_rows() > 0){
				
				$results = $query->result_array();
				
				// Retrieve total number of results without LIMIT clause
				$query = $this->db->query("
					SELECT FOUND_ROWS() AS record_count
				");
				
				if ($query->num_rows() === 1){
					$records = $query->result();
					
					$record_count = $records[0]->record_count;
				
				} else {
					return false;	
				}
				
				$logged_in = ($this->session->userdata('username')) ? 1 : 0;
				
				$comments['comments'] = $results;
				$comments['logged_in'] = $logged_in;
				$comments['comment_count'] = $record_count;
				$comments['comments_per_page'] = $this->comments_per_page;
				$comments['more_results'] = $this->more_results($position, $record_count, $this->comments_per_page);
				
				return $comments;
				
			} else 
				return false;
		}
	}
	
	private function more_results($position, $record_count, $comments_per_page){
		
		if (($position + $comments_per_page) < $record_count)
			return 1;
		else
			return 0;	
		
	}
		
/*
	------------------------------
	--			Comment reviews
	------------------------------
*/
	
	public function comment_review(){
		
		$errors = $this->valid_data();
		
		$error = '';		
		
		if (!empty($errors)) return $errors;
			
		// -- Prevent duplicate comments on each review
		if ($this->comment_exists())
			return $error = 'You have already commented on this review.';
			
									
		
		// Get post data
		$title = strip_tags($this->input->post('title'));
		$description = nl2br(strip_tags($this->input->post('description')));
		$rating = $this->input->post('rating');
		$id = $this->input->post('review_id');
		$user_id = $this->session->userdata('user_id');
		
		
		
		$this->load->database();
		
		$this->db->query("START TRANSACTION");		
		$this->db->query("
		
		INSERT INTO comments
		(title, review_id, rating, user_id, date)
		VALUES
		(?, ?, ?, ?, CURDATE())
		
		", array($title, $id, $rating, $user_id));		
		
		
		
		if ($this->db->affected_rows() != 1)
			$error = "Could not insert review.";
			
		else {
			$commentID = $this->db->insert_id();
				
			//Insert description				
			$this->db->query("
			INSERT INTO comments_descriptions
			(comment_id, description)
			VALUES
			(?, ?)			
			", array($commentID, $description));		
			
				
			// If description could not be inserted
			// then rollback					
			
			if ($this->db->affected_rows() !== 1){
				$this->db->query("ROLLBACK");
				
				$error = "Could not insert comment.";
			} else {
				$this->db->query("COMMIT");
			}			
		}
			
		return $error;		
	}
	
	private function valid_data(){
		$error = '';
		
		// If form data is valid continue with review insert
		$title = $this->input->post('title');
		$rating = $this->input->post('rating');
		
		// Validate review data from post
		
		$this->load->library('form_validation');
		
		$this->form_validation->set_rules('title', 'Title', 'required|min_length[4]|max_length[50]|xss_clean|trim');
		$this->form_validation->set_rules('rating', 'Rating', 'required|numeric|trim');
		$this->form_validation->set_rules('description', 'Description', 'required|min_length[15]|max_length[2650]|xss_clean|trim');
		$this->form_validation->set_rules('review_id', 'ID', 'required|numeric|trim');
		
		$this->form_validation->set_error_delimiters('', '');
		
		if ($this->form_validation->run() !== TRUE){
			$error = validation_errors();
			
			return $error;
		}			
			
		if (!$this->valid_title($title)){
			$error = 'Invalid characters in title.';
			
			return $error;
		}
		
		if (!$this->valid_rating($rating)){
			$error = 'Invalid rating number.';
			
			return $error;
		}
		
		return $error;
	}
	
	private function comment_exists(){
		
		// Check if user has already commented
		
		$review_id = $this->input->post('review_id');
		$user_id = $this->session->userdata('user_id');
		
		$this->load->database();
		$query = $this->db->query("
		
			SELECT 1
			FROM comments c
			WHERE c.review_id = ?
			AND c.user_id = ?
			LIMIT 1
			
		", array($review_id, $user_id));
		
		if ($query->num_rows() === 1)
			return true;
		else
			return false;		
	}
	
	// Validate id field to be a valid number
	public function valid_rating($r){
		
		$rating = (int) $r;
		// Check rating to be between 1-5
		if ($rating > 0 && $rating < 6)
			return TRUE;
		else 
			return FALSE;
	}
	
	// Disable certain symbols from being into the title for review
	public function valid_title($title){
		
		if (preg_match('/[^a-z0-9 \\/\.\'\[\]{}|"%*!?,;+&$()]/i', $title))			
			return FALSE;
		else
			return TRUE;
	}
	
/*
	------------------------------
	--			Like Comments
	------------------------------
*/
	
	public function like(){
		$error = '';
		
		if (!$this->session->userdata('username'))
			return 'You must be logged in to like this comment.';	
		
		$this->load->library('form_validation');
		$this->form_validation->set_rules('comment_id', 'comment_id', 'required|numeric');
		$this->form_validation->set_rules('action', 'action', 'required|alpha');
		
		if ($this->form_validation->run() === true){
			
			$comment_id = $this->input->post('comment_id');
			$action = $this->input->post('action');
			$user_id = $this->session->userdata('user_id');
			
			// Force MySQL to throw exceptions
			mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);		
			
			// Create query based on action (like or dislike comment)
			if (strcmp($action, 'like') == 0)
				$query = $this->query_like;
			else if (strcmp($action, 'unlike') == 0)
				$query = $this->query_unlike;
			else
				return 'Cannot like comment. Try again later.';
			
			// Query
			try {
				$this->db->query($query, array($user_id, $comment_id));
				
				if ($this->db->affected_rows() === 1)
					return '';
				else
					return 'Cannot like comment. Try again later.';
					
			} catch (Exception $e){
				return 'Cannot like comment. Try again later.';
			}	
		
		} else 
			$error = 'Cannot like comment. Try again later.';
		
		return $error;	
	}
}