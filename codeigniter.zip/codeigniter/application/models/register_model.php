<?php

class Register_model extends CI_Model {
	
	public function form_valid(){
		$this->load->database();
		$this->load->library('form_validation');
		
		$this->form_validation->set_rules('username', 'Username', 'required|alpha_numeric|min_length[4]|max_length[15]|is_unique[users.username]|xss_clean|trim');
		$this->form_validation->set_rules('email', 'Email', 'required|valid_email|is_unique[users.email]|xss_clean|trim');
		$this->form_validation->set_rules('password', 'Password', 'required|alpha_numeric|min_length[8]|max_length[20]|trim');
		$this->form_validation->set_rules('confirm', 'Confirm', 'required|matches[password]|trim');
		
		if ($this->form_validation->run() !== FALSE)
			return TRUE;
		else
			return FALSE;
	}
	
	public function activate(){
		
	}
	
	public function insert_user(){
		$this->load->model('global_data', 'global');
		$error = NULL;
		
		if ($this->form_valid()){
			$username = strip_tags($this->global->escape($this->input->post('username')));
			$email = strip_tags($this->input->post('email'));
			$password = $this->input->post('password');
			$activation = $this->global->random_string();			
			
			$query = $this->db->query("
				INSERT INTO users
				(username, email, password, activation, date_joined)
				VALUES
				(?, ?, sha2(?, 256), ?, CURDATE())
			",
				array($username, $email, $password, $activation, $date)
			);
			
			if ($this->db->affected_rows() !== 1)
				$error = 'could not insert user';
				
		} else {
			$error = validation_errors();
		}
		
		return $error;
	}
}